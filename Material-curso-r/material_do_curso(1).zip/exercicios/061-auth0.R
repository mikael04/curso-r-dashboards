# auth0
#
# Utilizando o pacote auth0, coloque tela de login no app
# feito no exercício 060-htmlwidgets.R.
#
