# UI reativa
# 
# Construa um shiny app que possua um filtro de delegacia
# que depende de um filtro de município
# que depende de um filtro de região.
#
# Como output, faça uma série temporal do número de furtos.